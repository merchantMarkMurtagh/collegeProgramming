module Main where

import Lab01

main = putStrLn thisIsLab01