module Main where

import Lab03

main = putStrLn thisIsLab03