module Main where

import Lab02

main = putStrLn thisIsLab02